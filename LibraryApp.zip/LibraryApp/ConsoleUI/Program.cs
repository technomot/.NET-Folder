﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using Core;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("=== Struct ===");

            BookPoint original = new BookPoint(3, 7);
            Console.WriteLine("Before method: " + original);
            ModifyPoint(original);
            Console.WriteLine("After method:  " + original);
            Console.WriteLine();

            
            Console.WriteLine("=== Boxing / Unboxing ===");

            int elementCount = 1_000_000;
            Stopwatch sw = new Stopwatch();

            System.Collections.ArrayList arrayList = new System.Collections.ArrayList();
            sw.Start();
            for (int i = 0; i < elementCount; i++)
                arrayList.Add(i);
            sw.Stop();
            long arrayListTime = sw.ElapsedMilliseconds;
            Console.WriteLine($"ArrayList (boxing):    {arrayListTime} ms");

            List<int> genericList = new List<int>();
            sw.Restart();
            for (int i = 0; i < elementCount; i++)
                genericList.Add(i);
            sw.Stop();
            long genericListTime = sw.ElapsedMilliseconds;
            Console.WriteLine($"List<int> (no boxing): {genericListTime} ms");
            Console.WriteLine($"Difference:            {arrayListTime - genericListTime} ms");
            Console.WriteLine();

          
            Console.WriteLine("===Collection of Books ===");

            List<Book> books = new List<Book>
            {
                new Book("Clean Code",               "Robert C. Martin", 431,  29.99, new DateTime(2008, 8,  1), true),
                new Book("The Pragmatic Programmer", "David Thomas",     352,  34.99, new DateTime(1999, 10, 1), true),
                new Book("Design Patterns",          "Gang of Four",     395,  44.99, new DateTime(1994, 11, 1), false),
                new Book("Refactoring",              "Martin Fowler",    448,  39.99, new DateTime(1999, 7,  1), true),
                new Book("Code Complete",            "Steve McConnell",  960,  49.99, new DateTime(2004, 6,  1), false),
                new Book("The Clean Coder",          "Robert C. Martin", 256,  29.99, new DateTime(2011, 5,  1), true),
                new Book("Introduction to Algorithms","Thomas Cormen",  1292,  79.99, new DateTime(2009, 7,  1), true),
                new Book("Head First Design Patterns","Eric Freeman",    694,  45.99, new DateTime(2004, 10, 1), false),
                new Book("You Don't Know JS",        "Kyle Simpson",     278,  19.99, new DateTime(2015, 3,  1), true),
                new Book("Structure and Interpretation","Harold Abelson",657,  55.99, new DateTime(1996, 7,  1), true),
            };

            Console.WriteLine($"Total books in collection: {books.Count}");
            Console.WriteLine();

            
            Console.WriteLine("=== LINQ Where (Price > 40) ===");

            List<Book> expensiveBooks = books.Where(b => b.Price > 40).ToList();
            foreach (var b in expensiveBooks)
                Console.WriteLine($"  {b.Title} - {b.Price:F2} USD");
            Console.WriteLine();
            Console.WriteLine("=== LINQ OrderBy (Author, then Pages) ===");

            List<Book> sortedBooks = books
                .OrderBy(b => b.Author)
                .ThenBy(b => b.Pages)
                .ToList();

            foreach (var b in sortedBooks)
                Console.WriteLine($"  {b.Author,-25} | {b.Pages,5} pages | {b.Title}");
            Console.WriteLine();

            
            Console.WriteLine("=== LINQ Select (Titles only) ===");

            List<string> titles = books.Select(b => b.Title).ToList();
            foreach (var title in titles)
                Console.WriteLine($"  {title}");
            Console.WriteLine();

            Console.WriteLine("============================================");
        }

        
        static void ModifyPoint(BookPoint p)
        {
            p.ShelfNumber = 999;
            p.PositionNumber = 999;
        }
    }
}